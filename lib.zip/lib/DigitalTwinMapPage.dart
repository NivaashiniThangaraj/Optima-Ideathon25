import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class DigitalTwinMapPage extends StatefulWidget {
  const DigitalTwinMapPage({super.key});

  @override
  _DigitalTwinMapPageState createState() => _DigitalTwinMapPageState();
}

class _DigitalTwinMapPageState extends State<DigitalTwinMapPage> {
  final Set<Marker> _markers = {};
  late GoogleMapController mapController;

  final firestore = FirebaseFirestore.instance;

  void _onMapCreated(GoogleMapController controller) {
    mapController = controller;
    _listenToUpdates();
  }

  void _listenToUpdates() {
    // Listen for Truck Location Updates
    firestore.collection('trucks').snapshots().listen((snapshot) {
      for (var doc in snapshot.docs) {
        final truck = doc.data();
        final location = truck['currentLocation'];

        final marker = Marker(
          markerId: MarkerId('truck_${doc.id}'),
          position: LatLng(location['lat'], location['lng']),
          infoWindow: InfoWindow(
            title: 'Truck: ${truck['driverName']}',
            snippet: 'Carrying: ${truck['materialCarrying']} (${truck['loadedQuantity']} units)',
          ),
          icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueBlue),
        );

        setState(() {
          _markers.removeWhere((m) => m.markerId == marker.markerId);
          _markers.add(marker);
        });
      }
    });

    // Listen for Warehouse Locations
    firestore.collection('warehouses').snapshots().listen((snapshot) {
      for (var doc in snapshot.docs) {
        final warehouse = doc.data();
        final location = warehouse['location'];

        final marker = Marker(
          markerId: MarkerId('warehouse_${doc.id}'),
          position: LatLng(location['lat'], location['lng']),
          infoWindow: InfoWindow(
            title: 'Warehouse: ${warehouse['name']}',
            snippet: 'Materials: ${(warehouse['materialsStored'] as List).join(", ")}',
          ),
          icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueGreen),
        );

        setState(() {
          _markers.removeWhere((m) => m.markerId == marker.markerId);
          _markers.add(marker);
        });
      }
    });

    // Listen for Material Usage on Sites (Optional)
    firestore.collection('materials').snapshots().listen((snapshot) {
      for (var doc in snapshot.docs) {
        final material = doc.data();
        final location = material['gpsLocation'];

        final marker = Marker(
          markerId: MarkerId('material_${doc.id}'),
          position: LatLng(location['lat'], location['lng']),
          infoWindow: InfoWindow(
            title: 'Material: ${material['name']}',
            snippet: 'Qty: ${material['quantity']} | Status: ${material['status']}',
          ),
          icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueYellow),
        );

        setState(() {
          _markers.removeWhere((m) => m.markerId == marker.markerId);
          _markers.add(marker);
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Digital Twin Map')),
      body: GoogleMap(
        onMapCreated: _onMapCreated,
        initialCameraPosition: const CameraPosition(
          target: LatLng(12.9716, 77.5946), // Bangalore center (example)
          zoom: 12,
        ),
        markers: _markers,
      ),
    );
  }
}
