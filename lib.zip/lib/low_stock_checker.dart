import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:firebase_auth/firebase_auth.dart';

final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
    FlutterLocalNotificationsPlugin();

// Initialize local notifications
Future<void> initNotifications() async {
  const AndroidInitializationSettings initializationSettingsAndroid =
      AndroidInitializationSettings('@mipmap/ic_launcher');

  const InitializationSettings initializationSettings = InitializationSettings(
    android: initializationSettingsAndroid,
  );

  await flutterLocalNotificationsPlugin.initialize(initializationSettings);

  // Request notification permission (for Android 13+)
  if (await Permission.notification.isDenied) {
    await Permission.notification.request();
  }
}

// Check materials and notify if quantity < threshold
Future<void> checkAndNotifyLowStock() async {
  final user = FirebaseAuth.instance.currentUser;
  if (user == null) {
    print("❌ No user. Skipping notification.");
    return;
  }

  // 👇 Cancel any previous notifications (they may be re-shown on app restart)
  await flutterLocalNotificationsPlugin.cancelAll();

  final materialsRef = FirebaseFirestore.instance
      .collection('users')
      .doc(user.uid)
      .collection('materials');

  final materialsSnapshot = await materialsRef.get();

  for (var doc in materialsSnapshot.docs) {
    final data = doc.data();

    final quantity = data['quantity'] ?? 0;
    final threshold = data['threshold'] ?? 0;
    final name = data['name'] ?? 'Unknown Material';

    if (quantity < threshold) {
      await flutterLocalNotificationsPlugin.show(
        doc.hashCode,
        'Low Stock Alert',
        '$name is below the threshold. Tap to place an order.',
        const NotificationDetails(
          android: AndroidNotificationDetails(
            'low_stock_channel',
            'Low Stock Alerts',
            channelDescription: 'Notifies when material is below threshold',
            importance: Importance.max,
            priority: Priority.high,
          ),
        ),
      );
    }
  }
}

